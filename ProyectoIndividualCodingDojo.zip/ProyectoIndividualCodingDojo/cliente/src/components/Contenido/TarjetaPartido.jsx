import React from 'react';
import '../Contenido/Tarjeta.css';
import ProgressBar from '../Contenido/BarraProgreso';
import { Link } from 'react-router-dom';

const TarjetaPartido = ({ juego, equipo1, equipo2, imagen1, imagen2, porcentaje, deporte, torneo, fecha }) => {
    const fechaDesdeProps = fecha;
    const date = new Date(fechaDesdeProps);

    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = date.toLocaleDateString('es-ES', options);
    
    return (
        <div>
            <p className='info-partido'>{fechaFormateada} - {torneo} - {deporte}</p>
            <div className='container-partido'>
                <img src={imagen1} alt={equipo1} className='img-partido'/>
                <h1 className='text-partido'>{equipo1}</h1>
                <ProgressBar porcentaje={porcentaje}/>
                <h1 className='text-partido'>{equipo2}</h1>
                <img src={imagen2} alt={equipo2} className='img-partido'/>
                <Link to={`/Details/${juego}`}>
                    <button className='boton-barra'>Equipos</button>
                </Link>
                <Link to={`/Predict/${juego}`}>
                    <button className='boton-barra'>Predecir</button>
                </Link>
            </div>
        </div>
    
    );
}

export default TarjetaPartido;
