import React from 'react';
import '../Contenido/Tarjeta.css';

const Tarjeta = ({ equipo }) => {
    if (!equipo) {
        return <p>No hay datos del equipo disponibles</p>;
    }

    return (
        <div className="equipo-container">
            <h2>{equipo.acronym}</h2>
            <ul>
                {equipo.players.map(player => (
                    <li key={player.id} className="integrante">
                        <img src={player.image_url} alt={player.name} className="integrante-img" />
                        <p>{player.first_name} "{player.name} " {player.last_name}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Tarjeta;
