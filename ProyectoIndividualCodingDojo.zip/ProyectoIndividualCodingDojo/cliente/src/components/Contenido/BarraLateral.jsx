import React from 'react';
import '../Contenido/Tarjeta.css'

const BarraLateral = () => {
    return (
        <div className='publicidad-container'>
            <img src="https://cdn.atomix.vg/wp-content/uploads/2019/10/manager-.jpg" alt="Módulo 1"  className='publicidad'/>
            <img src="https://www.egames.news/__export/1667153596469/sites/debate/img/2022/10/30/song_of_nunu_a_league_of_legends_story_no_saldrx_hasta_2023.jpg_242310155.jpg" alt="Módulo 2" className='publicidad'/>
            <img src="https://assets.tacter.com/images/open-graph/lol.png" alt="Módulo 3" className='publicidad'/>
        </div>
    );
}

export default BarraLateral;
