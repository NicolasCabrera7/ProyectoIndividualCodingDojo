import React, { useState, useEffect } from 'react';
import '../Contenido/BarraProgreso.css';

const ProgressBar = ({porcentaje}) => {
    const [progress, setProgress] = useState(0);
    useEffect(() => {
        setProgress(porcentaje);
    }, [porcentaje]);

    return (
        <div className="progress-bar-container">
            <div className="progress-bar-completed1" style={{ width: `${progress}%` }}>
                {Math.round(progress)}%
            </div>
            <div className="progress-bar-remaining1" style={{ width: `${100 - progress}%` }}>
                {Math.round(100 - progress)}%
            </div>
        </div>
    );
};

export default ProgressBar;
