import React, { useState } from 'react';
import Tarjeta from './TarjetaEquipo';
import { useState, useEffect } from 'react';

const App = () => {
    const [data, setData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
        try {
            const response = await axios.get('https://api.example.com/data');
            setData(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
        };
        fetchData();
    }, []);

    return (
        <div className="app-container">
            <h1>Información del Equipo</h1>
            <div>
                <Tarjeta equipo={data.rosters[0]} />
                <Tarjeta equipo={data.rosters[1]} />
            </div>
        </div>
    );
};

export default App;

