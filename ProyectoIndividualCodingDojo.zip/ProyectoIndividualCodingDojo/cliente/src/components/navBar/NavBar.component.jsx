import React from 'react';
import { Link } from 'react-router-dom';
import image from '../Images/Bet563.png';
import '../navBar/NavBar.css';
import { useNavigate } from 'react-router-dom';

function Navbar() {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        navigate('/');
    };
    const username = localStorage.getItem('username');

    return (
        <nav className="navbar">
            <img src={image} alt="Bet563-logo" className='logo'/>
            <ul className="navbar-nav">
                <li className="nav-item">
                    <Link to="/MainPage" className="nav-link">Inicio</Link>
                </li>
                <li className="nav-item">
                    <Link to="/Info" className="nav-link">Info</Link>
                </li>
                {username ? (
                    <>
                        <li className="nav-item">
                            <span className="nav-link-user">{username}</span>
                        </li>
                        <li className="nav-item">
                            <button className="nav-link-2" onClick={handleLogout}>LogOut</button>
                        </li>
                    </>
                ) : (
                    <>
                        <li className="nav-item">
                            <Link to="/" className="nav-link">Iniciar Sesión</Link>
                        </li>
                        <li className="nav-item-2">
                            <Link to="/">
                                <button className="nav-link-2">Registrarse</button>
                            </Link>
                        </li>
                    </>
                )}
            </ul>
        </nav>
    );
}

export default Navbar;

