import React from 'react';
import Navbar from '../navBar/NavBar.component';

const PageInfo = () => {
    return (
        <div>
            <Navbar/>
            <div className='pagina-info'>
                <h1>Información de la página:</h1>
                <img src='https://uvn-brightspot.s3.amazonaws.com/assets/vixes/btg/vegeta-goku-saludo.gif' alt="GIF" />
                <h1>La verdad no sabia mas que poner en esta pestaña asi que</h1><br/>
                <h1>**Inserte informacion importante aqui**</h1>
            </div>
        </div>
    );
}

export default PageInfo;

