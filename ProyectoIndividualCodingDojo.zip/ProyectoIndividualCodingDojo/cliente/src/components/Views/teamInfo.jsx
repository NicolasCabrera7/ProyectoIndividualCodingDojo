import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProgressBar from '../Contenido/BarraProgreso';
import Navbar from '../navBar/NavBar.component';
import '../Views/teamInfo.css';
import data from '../Contenido/Equipos.json';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const TeamInfo = () => {
    const equipoId = useParams().equipoId;
    const [partido, setPartido] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/auth/match');
                const partidoEncontrado = response.data.find(partido => partido.juego === equipoId);
                setPartido(partidoEncontrado);
                console.log(partidoEncontrado);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, [equipoId]);

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    if (!partido) {
        return <div>Loading...</div>;
    }

    const [equipo1Acronym, equipo2Acronym] = equipoId.split("-");
    const team1 = data.rosters.find(equipo => equipo.acronym === equipo1Acronym);
    const team2 = data.rosters.find(equipo => equipo.acronym === equipo2Acronym);


    const fechaDesdeProps = partido.Fecha;
    const date = new Date(fechaDesdeProps);

    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = date.toLocaleDateString('es-ES', options);
    
    return (
        <div>
            <Navbar />
            <div className='barra-info'>
                <p className='info-partido'>{fechaFormateada} - {partido.Torneo} - {partido.Deporte}</p>
                <div className='container-partido'>
                    <img src={partido.imagen1} alt={partido.equipo1} className='img-partido' />
                    <h1 className='text-partido'>{partido.equipo1}</h1>
                    <ProgressBar porcentaje={partido.Porcentaje} />
                    <h1 className='text-partido'>{partido.equipo2}</h1>
                    <img src={partido.imagen2} alt={partido.equipo2} className='img-partido' />
                </div>
            </div>
            <div className='main-container'>
                <div className='equipo-container'>
                    <h1 className='team-text'>{team1.name}</h1>
                    {team1.players.map(player => (
                        <div key={player.id}>
                            <img src={player.image_url} alt={player.name} className='img-player' />
                            <p>{player.first_name} "{player.name}" {player.last_name}</p>
                        </div>
                    ))}
                </div>

                <div className='equipo-container'>
                    <h1 className='team-text'>{team2.name}</h1>
                    {team2.players.map(player => (
                        <div key={player.id}>
                            <img src={player.image_url} alt={player.name} className='img-player' />
                            <p>{player.first_name} "{player.name}" {player.last_name}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default TeamInfo;
