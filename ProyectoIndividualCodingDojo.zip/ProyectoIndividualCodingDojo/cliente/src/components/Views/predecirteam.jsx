import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../navBar/NavBar.component';
import data from '../Contenido/Equipos.json';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Predict = () => {
    const equipoId = useParams().equipoId;
    const [partido, setPartido] = useState(null);
    const navigate = useNavigate();
    const [votos, setVotos] = useState({
        opcion1: false,
        opcion2: false,
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/auth/match');
                const partidoEncontrado = response.data.find(partido => partido.juego === equipoId);
                setPartido(partidoEncontrado);
                
                const totalVotos = partidoEncontrado.votosA + partidoEncontrado.votosB;
                const porcentaje = totalVotos === 0 ? 0 : (partidoEncontrado.votosA / totalVotos) * 100;
                
                setPartido(prevPartido => ({
                    ...prevPartido,
                    Porcentaje: porcentaje
                }));
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
        const interval = setInterval(() => {
            fetchData();
        }, 10); 

        return () => clearInterval(interval); 
    }, [equipoId]);

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    if (!partido) {
        return <div>Loading...</div>;
    }
    
    const handleCheckboxChange = (opcion) => {
        setVotos((prevVotos) => ({
        ...Object.fromEntries(Object.entries(prevVotos).map(([key, value]) => [key, key === opcion])),
        }));
    };
    
    const handleVoto = async () => {
        try {
            let votoSeleccionado = null;
            if (votos.opcion1) {
                votoSeleccionado = 'votosA'; 
            } else if (votos.opcion2) {
                votoSeleccionado = 'votosB';
            }
            let votoActualizado = equipoId + votoSeleccionado;
            console.log(votoSeleccionado)
            if (!votoSeleccionado) {
                alert('Por favor, selecciona una opción antes de votar');
                return;
            }
            const updatedPartido = {
                ...partido,
                [votoSeleccionado]: partido[votoSeleccionado] + 1
            };
            const usuario = localStorage.getItem('username');
            const response = await axios.post(`http://localhost:5000/api/auth/users`);
            let userFound = null;
            response.data.forEach(user => {
                if (user.username === usuario) {
                    userFound = user;
                    return;
                }
            });
            const userPartidos = userFound.votoPartidos;
            let voto = equipoId + "votosA";
            let indexOfEquipo = userPartidos.findIndex(partido => partido === voto);
            if(indexOfEquipo !== -1){
                updatedPartido["votosA"] -= 1;
                userPartidos[indexOfEquipo] = votoActualizado;
                await axios.put(`http://localhost:5000/api/auth/partidos/${userFound._id}`, { votoPartidos: userPartidos });
            }else{
                voto = equipoId + "votosB";
                indexOfEquipo = userPartidos.findIndex(partido => partido === voto);
                if(indexOfEquipo !== -1){
                    updatedPartido["votosB"] -= 1;
                    userPartidos[indexOfEquipo] = votoActualizado;
                    await axios.put(`http://localhost:5000/api/auth/partidos/${userFound._id}`, { votoPartidos: userPartidos });
                }else{
                    userPartidos.push(votoActualizado);
                    await axios.put(`http://localhost:5000/api/auth/partidos/${userFound._id}`, { votoPartidos: userPartidos });
                }
            }

            await axios.put(`http://localhost:5000/api/auth/match/${partido._id}`, updatedPartido);
    
            setPartido(updatedPartido);
            alert('¡Tu voto ha sido registrado!');
        } catch (error) {
            console.error('Error al registrar el voto:', error);
            alert('Hubo un error al registrar tu voto. Por favor, intenta de nuevo más tarde.');
        }
    };

    const [equipo1Acronym, equipo2Acronym] = equipoId.split("-");
    const team1 = data.rosters.find(equipo => equipo.acronym === equipo1Acronym);
    const team2 = data.rosters.find(equipo => equipo.acronym === equipo2Acronym);


    const fechaDesdeProps = partido.Fecha;
    const date = new Date(fechaDesdeProps);

    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = date.toLocaleDateString('es-ES', options);
    
    return (
        <div>
            <Navbar />
            <div className='barra-info'>
                <p className='info-partido'>{fechaFormateada} - {partido.Torneo} - {partido.Deporte}</p>
                <div className='container-partido'>
                    <img src={partido.imagen1} alt={partido.equipo1} className='img-partido' />
                    <h1 className='text-partido'>{partido.equipo1}</h1>
                    <h1 className='text-partido'>VS</h1>
                    <h1 className='text-partido'>{partido.equipo2}</h1>
                    <img src={partido.imagen2} alt={partido.equipo2} className='img-partido' />
                </div>
            </div>
            <div className='prediccion'>
                <h1>Predicciones Actuales</h1> <br/>

                <div>
                    <h1 className='text1'>{team1.name}</h1>
                    <h1 className='text2'>{team2.name}</h1>
                </div>

                <div className="progress-bar-container2">
                    <div className="progress-bar-completed" style={{ width: `${partido.Porcentaje}%` }}>
                        {Math.round(partido.Porcentaje)}%
                    </div>
                    <div className="progress-bar-remaining" style={{ width: `${100 - partido.Porcentaje}%` }}>
                        {Math.round(100 - partido.Porcentaje)}%
                    </div>
                </div>


                <div><br/><br/>
                    <h2>Selecciona una opción:</h2>
                    <div className='voto-container'>
                        <label>
                        <input
                            type="checkbox"
                            checked={votos.opcion1}
                            onChange={() => handleCheckboxChange('opcion1')}
                        />
                        {team1.name}
                        </label>
                        <br />
                        <label>
                        <input
                            type="checkbox"
                            checked={votos.opcion2}
                            onChange={() => handleCheckboxChange('opcion2')}
                        />
                        {team2.name}
                        </label>
                        <button onClick={handleVoto}>Registrar Voto</button>
                    </div><br/><br/><br/>
                </div>
            </div>
        </div>
    );
};

export default Predict;
