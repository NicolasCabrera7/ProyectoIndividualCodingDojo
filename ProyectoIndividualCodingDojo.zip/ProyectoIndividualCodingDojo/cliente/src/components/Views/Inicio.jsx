import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../navBar/NavBar.component';
import BarraLateral from '../Contenido/BarraLateral';
import TarjetaPartido from '../Contenido/TarjetaPartido';
import { useNavigate } from 'react-router-dom';
function App() {
    const [juegos, setJuegos] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/auth/match');
                setJuegos(response.data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, []);

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    return (
        <div style={{ display: 'flex' }}>
            <Navbar />
            <BarraLateral />
            <div style={{ flex: 1 }}>
                {juegos !== null && juegos.map((partido, index) => (
                    <TarjetaPartido
                        key={index}
                        equipo1={partido.equipo1}
                        equipo2={partido.equipo2}
                        imagen1={partido.imagen1}
                        imagen2={partido.imagen2}
                        porcentaje={partido.Porcentaje}
                        fecha={partido.Fecha}
                        torneo={partido.Torneo}
                        deporte={partido.Deporte}
                        juego={partido.juego}
                    />
                ))}
            </div>
        </div>
    );
}

export default App;