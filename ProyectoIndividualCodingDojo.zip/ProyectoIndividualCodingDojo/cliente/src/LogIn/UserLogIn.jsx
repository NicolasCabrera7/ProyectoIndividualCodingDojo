import React, { useState } from 'react';
import axios from 'axios';
import '../LogIn/UserLogin.css';
import { useNavigate } from 'react-router-dom';

const UserLogin = () => {
    
    const navigate = useNavigate();
    const [registerData, setRegisterData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        votoPartidos: []
    });

    const [loginData, setLoginData] = useState({
        username: '',
        password: ''
    });

    const handleRegisterChange = (e) => {
        const { name, value } = e.target;
        setRegisterData({ ...registerData, [name]: value });
    };

    const handleLoginChange = (e) => {
        const { name, value } = e.target;
        setLoginData({ ...loginData, [name]: value });
    };

    const handleRegisterSubmit = async (e) => {
        e.preventDefault();
        if (registerData.password !== registerData.confirmPassword) {
            alert("Las contraseñas no coinciden");
            return;
        }
        try {
            const response = await axios.post("http://localhost:5000/api/auth/register", registerData);
            console.log(response);
            localStorage.setItem('username', registerData.username);
            localStorage.setItem('token', response.data.token);
            navigate('/MainPage');
            alert("Usuario registrado correctamente");
        } catch (error) {
            console.error('Error:', error);
            alert("Error al registrar usuario");
        }
    };

    const handleLoginSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/api/auth/login", loginData);
            console.log(response);
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('username', loginData.username)
            navigate('/MainPage');
            alert("Inicio de sesión exitoso");
        } catch (error) {
            console.error('Error:', error);
            alert("Error al iniciar sesión");
        }
    };

    return (
        <div className='home-container'>
            <div className="auth-container">
                <form className="login-form" onSubmit={handleLoginSubmit}>
                    <h2>Iniciar Sesión</h2>
                    <p>Username</p>
                    <input 
                        type="text" 
                        name="username" 
                        placeholder="" 
                        value={loginData.email} 
                        onChange={handleLoginChange} 
                    />
                    <p>Contraseña</p>
                    <input 
                        type="password" 
                        name="password" 
                        placeholder="" 
                        value={loginData.password} 
                        onChange={handleLoginChange} 
                    />
                    <button type="submit" className="btn2">Iniciar Sesión</button>
                </form>
                <form className="register-form" onSubmit={handleRegisterSubmit}>
                    <h2>Registrarse</h2>
                    <p>Usuario</p>
                    <input 
                        type="text" 
                        name="username" 
                        placeholder="" 
                        value={registerData.username} 
                        onChange={handleRegisterChange} 
                    />
                    <p>Correo</p>
                    <input 
                        type="text" 
                        name="email" 
                        placeholder="" 
                        value={registerData.email} 
                        onChange={handleRegisterChange} 
                    />
                    <p>Contraseña</p>
                    <input 
                        type="password" 
                        name="password" 
                        placeholder="" 
                        value={registerData.password} 
                        onChange={handleRegisterChange} 
                    />
                    <p>Confirmar Contraseña</p>
                    <input 
                        type="password" 
                        name="confirmPassword" 
                        placeholder="" 
                        value={registerData.confirmPassword} 
                        onChange={handleRegisterChange} 
                    />
                    <button type="submit" className="btn2">Registrarse</button>
                </form>
            </div>
        </div>
    );
};

export default UserLogin;

