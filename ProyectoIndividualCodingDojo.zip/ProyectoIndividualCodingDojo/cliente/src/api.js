const axios = require('axios');

const options = {
    method: 'GET',
    url: 'https://livescore6.p.rapidapi.com/matches/v2/list-live',
    params: {
        Category: 'soccer',
        Timezone: '-7'
    },
    headers: {
        'X-RapidAPI-Key': '7e03dcc158msh15033541d205695p1b014fjsn08f3bf574603',
        'X-RapidAPI-Host': 'livescore6.p.rapidapi.com'
    }
};

try {
	const response = await axios.request(options);
	console.log(response.data);
} catch (error) {
	console.error(error);
}