import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Inicio from './components/Views/Inicio';
import UserLogin from '../src/LogIn/UserLogIn';
import TeamInfo from './components/Views/teamInfo';
import Predict from './components/Views/predecirteam';
import PageInfo from './components/Views/Info';

function App() {
  return (
    
    <Router>
      <Routes>
        <Route path="/MainPage" element={<Inicio/>} />
        <Route path="/Details/:equipoId" element={<TeamInfo/>} />
        <Route path="/" element={<UserLogin/>} />
        <Route path="/Predict/:equipoId" element={<Predict/>} />
        <Route path="/Info" element={<PageInfo/>} />
      </Routes>
    </Router>
  );
}

export default App;
