const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/users.model');
const Partido = require('../models/partidos.model');

exports.getAllMatches = async (req, res) => {
    try {
        const matches = await Partido.find();
        res.status(200).json(matches);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.createMatch = async (req, res) => {
    try {
        const newMatch = await Partido.create(req.body)
        res.status(201).json(newMatch)
    } catch (error) {
        res.status(500).json({message: error})
    }
};

exports.updateMatch = async (req, res) => {
    try {
        const updatedMatch = await Partido.findOneAndUpdate(
            { _id: req.params.id },
            req.body,
            { new: true }
        )
        res.status(200).json(updatedMatch)
        
    } catch (error) {
        res.status(500).json({message: error})
    }
};

exports.register = async (req, res) => {
    try {
        const { username, password, email } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword, email });
        await user.save();
        const token = jwt.sign({ userId: user._id }, 'secret_key', { expiresIn: '1h' });
        res.status(200).json({ token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: 'No se encontro al usuario' });
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ message: 'Contraseña incorrecta'});
        }
        const token = jwt.sign({ userId: user._id }, 'secret_key', { expiresIn: '1h' });
        res.status(200).json({ token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.users = async(req, res) => {
    try {
        const matches = await User.find();
        res.status(200).json(matches);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}
exports.updatePartidos = async (req, res) => {
    try {
        const update = { $set: { votoPartidos: req.body.votoPartidos } }; 
        const updatedUser = await User.findOneAndUpdate(
            { _id: req.params.id },
            update,
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "Usuario no encontrado" });
        }

        res.status(200).json(updatedUser);
    } catch (error) {
        res.status(500).json({ message: error });
    }
};
