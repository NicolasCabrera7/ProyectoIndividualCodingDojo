const express = require('express');
const router = express.Router();
const authController = require('../controllers/users.controller');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/match', authController.getAllMatches);
router.post('/match', authController.createMatch);
router.put('/match/:id', authController.updateMatch);
router.post('/users', authController.users);
router.put('/partidos/:id', authController.updatePartidos);

module.exports = router;

