const mongoose = require('mongoose');

const partidoSchema = new mongoose.Schema({
    juego: {
        type: String,
        required: true
    },
    equipo1: {
        type: String,
        required: true
    },
    equipo2: {
        type: String,
        required: true
    },
    imagen1: String,
    imagen2: String,
    Torneo: {
        type: String,
        required: true
    },
    votosA: {
        type: Number,
        required: true,
    },
    votosB: {
        type: Number,
        required: true,
    },
    Porcentaje: {
        type: Number,
        required: true
    },
    Fecha: {
        type: Date,
        required: true
    },
    Deporte: {
        type: String,
        required: true
    }
});

partidoSchema.pre('save', function(next) {
    if (this.isNew || this.isModified('votosA') || this.isModified('votosB')) {
        const totalVotos = this.votosA + this.votosB;
        if (totalVotos === 0) {
            this.Porcentaje = 0;
        } else {
            this.Porcentaje = Math.round((this.votosA / totalVotos) * 100);
        }
    }
    next();
});


module.exports = mongoose.model('Partido', partidoSchema);
